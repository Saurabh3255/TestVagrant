package com.testVagrant;

import java.util.LinkedList;
import java.util.Scanner;

public class IPL 
{
	static Scanner sc=new Scanner(System.in);    //i have created this to accesses this for switch cases.
	static LinkedList cl=new LinkedList();		//i have created this linked list for 2 consecutive hardcoding way. 
	static LinkedList duc=new LinkedList();		//i have created this linked list for dynamically for n consecutive.
	public static void main(String[] args)
	{
		LinkedList ls=new LinkedList(); 		//this linked list  to store the details for the team. 
		
		System.out.println("enter team 1 to 10");
		int limit=sc.nextInt();
		if(limit>10)
		{
			System.err.println("user you should enter within 10 teams ");
			String[]a= {};
			main(a);
		}
		else
		{
			for(int i=1;i<=limit;i++)
			{
				System.out.println("enter team name");
				String name=sc.next();
				System.out.println("enter team points");
				int points=sc.nextInt();
				Team t=new Team(name,points);
				ls.add(t);
				System.out.println("team is added");
			}
		}
		for(;;)
		{
			System.out.println("1.you want check 2 consective lose 2.you want check dynamically 3.average of consective 2 times lossed 4.dynamic average");
			int choice=sc.nextInt();
			switch(choice)
			{
			case 1:
			{
				for(int i=0;i<ls.size();i++)
				{
					Team t=(Team)ls.get(i);
					isWinOrLoss(t);
				}
			}
				break;
			case 2:
			{
				System.out.println("you wqant to check win or loss");
				char c1=sc.next().charAt(0);
				System.out.println("how many times u want to check");
				int c2=sc.nextInt();
				for(int i=0;i<ls.size();i++)
				{
					Team t=(Team)ls.get(i);
					isDynamic(t,c1,c2);	
				}

				
			}
			break;
			case 3:
			{
				average(cl);
				break;
			}
			case 4:
			{
				average(duc);
				break;
			}
			
			case 5:
				System.err.println("appication is closed");
				System.exit(1);
				
				default:
					System.out.println("user you have entered more than range pls restart the application");
					
					
			}
			
		}
		
		
	}
	public static void isWinOrLoss(Team t)
	{
		char[]ch=t.ch;
		for(int i=0;i<ch.length;i++)
		{
			if(i!=ch.length-1)
			{
				if(ch[i]=='l'&&ch[i+1]=='l')
				{
					System.err.println(t);
					cl.add(t);
					break;
				}
			}
		}
		
		
	}
	public static void isDynamic(Team t,char c1,int c2)
	{
		
	     char[]c3=	t.ch;
	     int c=0;
		for(int i=0;i<c3.length;i++)
		{
			if(c1==c3[i])
			{
				c++;
				if(c==c2)
				{
					System.out.println(t);
					duc.add(t);
					break;
				}
			}
			else
			{
				c=0;
			}
		}
		
	}
	public static void average(LinkedList l)
	{
		int average=0;
		for(int i=0;i<l.size();i++)
		{
			Team t=(Team)l.get(i);
			average+=t.point;
		}
		System.err.println("Average of "+average/l.size());
	}
	

}
