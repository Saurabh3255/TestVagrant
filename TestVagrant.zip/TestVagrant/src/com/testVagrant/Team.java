package com.testVagrant;

import java.util.Scanner;

public class Team
{
	String name;
	int point;
	char[]ch=new char[5];  					//i have created this for the [w,l,w,l,w]
	Scanner sc=new Scanner(System.in);
	public Team(String name, int point) {
		
		this.name = name;
		this.point = point;
		isStore();
	}
	public void isStore()
	{
		for(int i=0;i<ch.length;i++)
		{
			System.err.println("enter W or L");
			ch[i]=sc.next().charAt(0);				
		}
	}
	public String toString()
	{
		String s1="";
		s1=name+" "+point+" ";
		for(int i=0;i<ch.length;i++)
		{
			s1=s1+ch[i];
		}
		return s1;
	}
	

}
